# README #

DU-DIC Project for listing accessible portions