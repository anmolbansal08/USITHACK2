package ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import org.json.JSONObject;

import adapter.ImageGridAdapter;
import app.Constants;
import app.User;
import butterknife.BindView;
import butterknife.ButterKnife;
import dudic.accieo.R;

public class AddPlace extends AppCompatActivity implements AdapterView.OnItemClickListener {
    Intent intent;
    double lat, lang;
    String placeName, address;
    Context mContext;
    CheckBoxAdapter checkBoxAdapter;

    @BindView(R.id.addressField)
    EditText addressField;

    @BindView(R.id.placeField)
    EditText placeField;

    @BindView(R.id.place_type_grid)
    GridView placeTypeGrid;

    @BindView(R.id.facilities_type_grid)
    GridView facilitiesTypeGrid;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    String accessLevel = "-1", TAG = AddPlace.class.getSimpleName();
    int place_type = 0;
    int[] placeTypes;
    String[] facilitiesTypes;
    String facilities = "";
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_place);

        initUI();


    }

    private void initUI() {
        mContext = this;
        intent = getIntent();
        ButterKnife.bind(this);

        user = new User(this);

        lat = intent.getDoubleExtra(Constants.LATITUDE, 0);
        lang = intent.getDoubleExtra(Constants.LONGITUDE, 0);

        placeName = intent.getStringExtra(Constants.PLACE_NAME);
        address = intent.getStringExtra(Constants.ADDRESS);

        addressField.setText(address);
        placeField.setText(placeName);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(R.string.add_info);

        placeTypes = Constants.PLACE_TYPE_IMAGES;
        placeTypeGrid.setAdapter(new ImageGridAdapter(this, placeTypes));

        checkBoxAdapter = new CheckBoxAdapter(this);
        facilitiesTypes = Constants.FACILITIES_TYPE_NAMES;
        facilitiesTypeGrid.setAdapter(checkBoxAdapter);


        placeTypeGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //showToast(position + " ");
                placeTypeGrid.getChildAt(place_type).setAlpha((float) 0.3);
                place_type = position;
                view.setAlpha((float) 1.0);
            }
        });



    }


    public void dismiss() {
        finish();
    }

    public void submitPlace() {

        if (!isInputValid()) {
            showToast(getString(R.string.invalid_input));
            return;
        }

        Log.e(TAG, user.getToken());


        // Log.e("Pro", facilities + " hi " + checkBoxAdapter.mCheckStates.length + " " + Constants.FACILITIES_TYPE_NAMES.length);
        for (int i = 0; i < checkBoxAdapter.mCheckStates.length; i++) {
            // Log.e("ITR", Constants.FACILITIES_TYPE_NAMES[i] + " " + checkBoxAdapter.mCheckStates[i]);
            if (checkBoxAdapter.mCheckStates[i])
                facilities += Constants.FACILITIES_TYPE_NAMES[i] + ", ";
        }
        Log.e("Pro", facilities + " hi");


        if (facilities.length() == 0)
            return;

        placeName = placeField.getText().toString();
        address = addressField.getText().toString();

        Ion.with(mContext)
                .load(Constants.ADDPLACES)
                .setBodyParameter(Constants.ACTUAL_ADDRESS, address).setBodyParameter(Constants.PLACE_NAME, placeName)
                .setBodyParameter(Constants.TOKEN, user.getToken()).setBodyParameter(Constants.ACCESSIBLITY_LEVEL, accessLevel)
                .setBodyParameter(Constants.LATITUDE, lat + "").setBodyParameter(Constants.LONGITUDE, lang + "")
                .setBodyParameter(Constants.PLACE_TYPE, place_type + "").setBodyParameter(Constants.FACILITIES,
                facilities.subSequence(0, facilities.length() - 2) + "")
                .asString()
                .setCallback(new FutureCallback<String>() {
            @Override
            public void onCompleted(Exception e, String result) {
                if (e != null) {
                    showToast(getString(R.string.server_problem));
                    Log.e(TAG, "e: " + e.toString());
                    return;
                }

                Log.e(TAG, result);
                Log.e(TAG, "LEN " + result.length());

                try {
                    JSONObject json = new JSONObject(Constants.formatResponse(result));
                    showToast(json.getString(Constants.MESSAGE));
                    if (json.getString(Constants.STATUS).equals("200")) {
                        startActivity(new Intent(mContext, Maps.class));
                    }
                } catch (Exception e1) {
                    Log.e(TAG, e1.toString());
                }
            }
        });

    }

    boolean isInputValid() {
        return address.length() > 2 && placeName.length() > 2 && accessLevel != null && lat != 0 && lang != 0 && place_type != -1;
    }

    public void addLevel(View v) {
        switch (v.getId()) {
            case R.id.na:
                accessLevel = "0";
                break;
            case R.id.ma:
                accessLevel = "1";
                break;
            case R.id.va:
                accessLevel = "2";
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_add_place, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                submitPlace();
                break;
            case R.id.action_dismiss:
                dismiss();
                break;
        }
        return true;
    }


    void showToast(final String s) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mContext, s, Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        checkBoxAdapter.toggle(position);
        //Log.e("Toogled", checkBoxAdapter.mCheckStates[position] + " ");
    }
}

class CheckBoxAdapter extends ArrayAdapter implements CompoundButton.OnCheckedChangeListener {
    public Boolean mCheckStates[];
    LayoutInflater mInflater;
    CheckBox cb;
    String[] fac;

    CheckBoxAdapter(AddPlace context) {
        super(context, 0);
        mCheckStates = new Boolean[]{false, false, false, false, false, false};
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        fac = Constants.FACILITIES_TYPE_NAMES;
        //   Log.e("Len ", " " + mCheckStates.length);
    }

    @Override
    public int getCount() {
        return Constants.FACILITIES_TYPE_NAMES.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void toggle(int position) {
        setChecked(position, !isChecked(position));
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;

        if (convertView == null)
            vi = mInflater.inflate(R.layout.checkbox_grid, null);

        cb = (CheckBox) vi.findViewById(R.id.facilityCheckBox);
        cb.setText(fac[position]);
        cb.setTag(position);
        //cb.setChecked(mCheckStates[position]);
        cb.setOnCheckedChangeListener(this);
        return vi;
    }

    public boolean isChecked(int position) {
        return mCheckStates[position];
    }

    public void setChecked(int position, boolean isChecked) {
        mCheckStates[position] = isChecked;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView,
                                 boolean isChecked) {
        setChecked((int) buttonView.getTag(), isChecked);
        //Log.e("On check changed", isChecked + " ");

        notifyDataSetChanged();
    }

}