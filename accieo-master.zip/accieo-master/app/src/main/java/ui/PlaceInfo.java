
package ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.parceler.Parcels;

import app.Constants;
import app.Place;
import butterknife.BindView;
import butterknife.ButterKnife;
import dudic.accieo.R;

public class PlaceInfo extends AppCompatActivity {

    @BindView(R.id.placeInfo)
    TextView placeInfoText;

    @BindView(R.id.place_type)
    ImageView placeType;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    Intent intent;
    String TAG = PlaceInfo.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_info);

        initUI();

    }

    private void initUI() {
        ButterKnife.bind(this);

        intent = getIntent();

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(R.string.more_info);

        Place clickedPlace = Parcels.unwrap(intent.getParcelableExtra(Constants.PLACE_OBJECT));

        if (clickedPlace == null)
            return;

        String info = clickedPlace.name + "\n" + clickedPlace.address + "\nFacilities available: " + clickedPlace.facilties
                + "\nAccessibility Score: " + Double.parseDouble(clickedPlace.rate);
        placeInfoText.setText(info);
        placeType.setImageResource(Place.getPlaceDrawable
                (Integer.parseInt(clickedPlace.type), Integer.parseInt(clickedPlace.rate)));
    }

    public void dismiss(View v) {
        finish();
    }
}
