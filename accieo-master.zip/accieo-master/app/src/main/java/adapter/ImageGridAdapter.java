package adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageGridAdapter extends BaseAdapter {

    Context mContext;
    int[] placeTypes;

    public ImageGridAdapter(Context context, int[] placeTypes) {
        mContext = context;
        this.placeTypes = placeTypes;
    }


    @Override
    public int getCount() {
        return placeTypes.length;
    }

    @Override
    public Object getItem(int position) {
        return placeTypes[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;

        if (convertView == null) {
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(80, 80));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            // imageView.setPadding(8, 8, 8, 8);
        } else
            imageView = (ImageView) convertView;

        imageView.setAlpha((float) 0.3);
        imageView.setImageResource(placeTypes[position]);
        return imageView;
    }
}
